﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace mvc2.ViewModels
{
    public class DepartmentViewModel
    {
        public string DepartmentName { get; set; }
        public List<SelectListItem> StudentsOver25 { get; set; }
        public string DepartmentState { get; set; }
    }
}
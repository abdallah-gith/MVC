﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using mvc2.Models;
using System.Linq;
using System.Threading.Tasks;

namespace mvc2.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly CorporateDbContext _context;

        public DepartmentController(CorporateDbContext context)
        {
            _context = context;
        }

        // GET: Department (ShowAll)
        public async Task<IActionResult> Index()
        {
            return View(await _context.Departments.ToListAsync());
        }

        // GET: Department/Details/5 (ShowDetails)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var department = await _context.Departments
                .FirstOrDefaultAsync(m => m.Id == id);
            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // GET: Department/Create (Add - GET)
        public IActionResult Create()
        {
            return View();
        }

        // POST: Department/Create (Add - POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,MgrName")] Department department)
        {
            if (ModelState.IsValid)
            {
                _context.Add(department);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(department);
        }

        // GET: Department/DepartmentDetailsWithViewModel/5
        public async Task<IActionResult> DepartmentDetailsWithViewModel(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var department = await _context.Departments
                .Include(d => d.Students)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (department == null)
            {
                return NotFound();
            }

            var viewModel = new ViewModels.DepartmentViewModel
            {
                DepartmentName = department.Name,
                StudentsOver25 = department.Students
                    .Where(s => s.Age > 25)
                    .Select(s => new SelectListItem { Text = s.Name, Value = s.Id.ToString() })
                    .ToList(),
                DepartmentState = department.Students.Count > 50 ? "Main" : "Branch"
            };

            return View(viewModel);
        }
    }
}
﻿using System.ComponentModel.DataAnnotations.Schema;

namespace mvc2.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Degree { get; set; }
        public int MinDegree { get; set; }

        [ForeignKey("Department")]
        public int DepartmentId { get; set; }

        [ForeignKey("Teacher")]
        public int? TeacherId { get; set; }

        public virtual Department Department { get; set; }
        public virtual Teacher? Teacher { get; set; }
        public virtual ICollection<StuCrsRes> StuCrsRes { get; set; } = new List<StuCrsRes>();
    }
}
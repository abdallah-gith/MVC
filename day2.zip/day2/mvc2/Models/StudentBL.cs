﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace mvc2.Models
{
    public class StudentBL
    {
        private readonly CorporateDbContext _context;

        public StudentBL(CorporateDbContext context)
        {
            _context = context;
        }

        // ===== تم التعديل ليطابق أسلوب مشروعك القديم =====
        public List<Student> GetAll()
        {
            // نرجع قائمة مباشرةً مع إضافة .Include() لحل الخطأ
            return _context.Students.Include(s => s.Department).ToList();
        }

        // ===== هذه الدالة تطابق أسلوب مشروعك القديم =====
        public Student GetById(int id)
        {
            return _context.Students
                           .Include(s => s.Department)
                           .Include(s => s.StuCrsRes)
                               .ThenInclude(scr => scr.Course)
                           .FirstOrDefault(s => s.Id == id);
        }
    }
}
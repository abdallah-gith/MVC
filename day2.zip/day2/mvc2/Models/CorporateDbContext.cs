﻿using Microsoft.EntityFrameworkCore;

namespace mvc2.Models
{
    public class CorporateDbContext : DbContext
    {
        public CorporateDbContext(DbContextOptions<CorporateDbContext> options) : base(options)
        {
        }

        public DbSet<Department> Departments { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<StuCrsRes> StuCrsRes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // --- Model Configuration ---
            modelBuilder.Entity<Teacher>(entity =>
            {
                entity.Property(e => e.Salary).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<StuCrsRes>()
                .HasKey(scr => new { scr.StudentId, scr.CourseId });

            modelBuilder.Entity<StuCrsRes>()
                .HasOne(s => s.Student)
                .WithMany(s => s.StuCrsRes)
                .HasForeignKey(s => s.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            // ===== البيانات الأولية (Seeding) =====
            modelBuilder.Entity<Department>().HasData(
                new Department { Id = 1, Name = "SD", MgrName = "Ahmed" },
                new Department { Id = 2, Name = "OS", MgrName = "Mona" }
            );

            modelBuilder.Entity<Student>().HasData(
                new Student { Id = 1, Name = "Ali", Age = 22, DepartmentId = 1 },
                new Student { Id = 2, Name = "Salma", Age = 21, DepartmentId = 2 },
                new Student { Id = 3, Name = "Hassan", Age = 23, DepartmentId = 1 }
            );

            // ... (باقي البيانات التي أضفناها سابقاً) ...

            base.OnModelCreating(modelBuilder);
        }
    }
}
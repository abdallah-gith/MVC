﻿using Microsoft.AspNetCore.Mvc;
using mvc2.Models;
using System.Collections.Generic; // <-- قد تحتاج هذا السطر

namespace mvc2.Controllers
{
    public class StudentController : Controller
    {
        private readonly StudentBL _studentBL;

        public StudentController(StudentBL studentBL)
        {
            _studentBL = studentBL;
        }

        // ===== تم تبسيط الكود هنا =====
        public IActionResult ShowAll()
        {
            List<Student> students = _studentBL.GetAll();
            return View(students);
        }

        // ===== تم تبسيط الكود هنا =====
        public IActionResult ShowDetails(int id)
        {
            Student student = _studentBL.GetById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }
    }
}